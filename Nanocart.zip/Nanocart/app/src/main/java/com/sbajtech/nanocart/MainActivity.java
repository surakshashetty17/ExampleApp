package com.sbajtech.nanocart;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

//import androidx.core.app.ActivityCompat;
//import androidx.core.content.ContextCompat;


public class MainActivity extends Activity {

    private WebView mWebView;
    private int LOCATION_PERMISSION_CODE = 1;
    public String mGeoLocationRequestOrigin;
//    public String mGeoLocationCallback;
    public GeolocationPermissions.Callback mGeoLocationCallback;



//    @Override
//    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
//    {
//        //Figure out what was given to us
//        switch(requestCode)
//        {
//            case 0:
//            {
//                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
//                {
//                    if (mGeoLocationCallback != null)
//                    {
//                        mGeoLocationCallback.invoke(mGeoLocationRequestOrigin, true, true);
//                    }
//                }
//                else
//                {
//                    if (mGeoLocationCallback != null)
//                    {
//                        mGeoLocationCallback.invoke(mGeoLocationRequestOrigin, false, false);
//                    }
//                }
//                return;
//            }
//        }
//    }
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        LocationRequest request = new LocationRequest()
//                .setFastestInterval(15000)
//                .setInterval(3000)
//                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);



        mWebView = findViewById(R.id.activity_main_webview);

        // Force links and redirects to open in the WebView instead of in a browser
        mWebView.setWebViewClient(new WebViewClient());


        // Enable Javascript
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        //webSettings.setAllowFileAccessFromFileURLs(true); //Maybe you don't need this rule
        //webSettings.setAllowUniversalAccessFromFileURLs(true);

        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_CODE);



//        ActivityCompat.requestPermissions(this,
//                new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_CODE);


        // REMOTE RESOURCE
         mWebView.loadUrl("https://nanocart.in/");
         mWebView.setWebViewClient(new MyWebViewClient());

        WebChromeClient mWebChromeClient = new WebChromeClient() {


            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin, final GeolocationPermissions.Callback callback) {
               mGeoLocationRequestOrigin = null;
               mGeoLocationCallback = null;

               if (ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
               {
                   if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION))
                   {
                       new AlertDialog.Builder(MainActivity.this)
                               .setMessage(R.string.permision_location_rationalate)
                               .setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() {
                                   @Override
                                   public void onClick(DialogInterface dialog, int i) {

                                       mGeoLocationRequestOrigin = origin;
                                       mGeoLocationCallback = callback;
                                       ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},LOCATION_PERMISSION_CODE);

                                   }
                               })
                               .show();
                   }
                   else
                   {
                       mGeoLocationRequestOrigin = origin;
                       mGeoLocationCallback = callback;
                       ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},LOCATION_PERMISSION_CODE);
                   }
               }
               else
               {
                   callback.invoke(origin,true,false);
               }

            }




        };

        mWebView.setWebChromeClient(mWebChromeClient);


        // LOCAL RESOURCE
       // mWebView.loadUrl("file:///android_asset/index.html");
    }



//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        if (requestCode == LOCATION_PERMISSION_CODE)  {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(this, "Permission GRANTED", Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
    // Prevent the back-button from closing the app
    @Override
    public void onBackPressed() {
        if(mWebView.canGoBack()) {
            mWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }

}
